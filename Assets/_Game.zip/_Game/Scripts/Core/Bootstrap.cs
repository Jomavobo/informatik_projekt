using UnityEngine;
using UnityEngine.SceneManagement;
using Mirror;
using System.Collections;

public class Bootstrap : MonoBehaviour
{
    public static Bootstrap Instance;

    [Header("Scenes")]
    public string shipScene = "Ship";
    public string galaxyScene = "Galaxy";

    void Awake()
    {
        if (Instance != null)
        {
            Destroy(gameObject);
            return;
        }

        Instance = this;
        DontDestroyOnLoad(gameObject);
    }

    IEnumerator Start()
    {
        AsyncOperation op = SceneManager.LoadSceneAsync(shipScene, LoadSceneMode.Additive);
        yield return op;
        SceneManager.SetActiveScene(SceneManager.GetSceneByName(shipScene));
    }

    public void LoadGalaxy()
    {
        SceneManager.LoadSceneAsync(galaxyScene, LoadSceneMode.Additive);
    }

    public void UnloadGalaxy()
    {
        SceneManager.UnloadSceneAsync(galaxyScene);
    }
}